			    Installation
-------------------------------------------------------------------

1. Put the [props] folder inside your resources
2. Ensure the [props]folder in your server.cfg
3. Add the props to spooni data file in Spooni Spooner

-------------------------------------------------------------------
			    Props Names
-------------------------------------------------------------------

demonskull
demonskull02
demonskull_mini
demonskull02_mini
ghost
halloween_pumpkin
halloween_pumkin02
halloween_pumkin03
plaguemask
plaguemask_mini

-------------------------------------------------------------------
			      Credits
-------------------------------------------------------------------

Burricidas Mapping Studios - Creator of all the props from this package
Spooni - Creators of spooni_spooner

-------------------------------------------------------------------
			   Discord Servers
-------------------------------------------------------------------

Burricidas Mapping Studios - https://discord.gg/b9JjRxq8S3
SPOONI Development - https://discord.gg/spooni
